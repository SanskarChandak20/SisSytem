<?php include("include/header.php");
if(isset($_POST['update_pass'])){
    $result=mysqli_query($con,"select * from user where detail_id=$_SESSION[staff_id]");
    $row=mysqli_fetch_assoc($result);
    // print_r($row);
  if ($row['password']==$_POST['opass'] && $_POST['npass']==$_POST['cpass']) {
        $update="update user set password='$_POST[npass]' where detail_id=$_SESSION[staff_id] ";
        if(mysqli_query($con, $update)){?>
                                    <div class="content">
                                    <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Records added successfully";?></span>
                                  </div>
        <?php } }else{ ?>
                                    <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "error";?></span>
                                  </div>
                                </div>
     <?php   }
  }
 ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Change Password</h4>
                  <p class="card-category"> Here you can Change Your Password</p>
                </div>
                <div class="card-body">
                  <form method="post">
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">Old Password</label>
                          <input type="Password" class="form-control" name="opass">
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">New Password</label>
                          <input type="Password" class="form-control" name="npass">
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">Confrim Password</label>
                          <input type="Password" class="form-control" name="cpass" >
                        </div>
                      </div>
                    </div>
                    <div class="col-md-5">
                       <!--  <div class="form-group"> -->
                         
                          <input type="Submit" class=" btn"  name="update_pass" >
                        <!-- </div> -->
                      </div>
                   
                      </div>  
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>