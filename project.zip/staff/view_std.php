<?php include("include/header.php"); 
$ed=mysqli_query($con,"select * from department");
if(isset($_GET["std_view_id"])){
  $result=mysqli_query($con,"select * from student_details join Department on student_details.Branch=Department.Department_Id where s_id=$_GET[std_view_id]");
   $row=mysqli_fetch_assoc($result);
}
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">View Student Detail</h4>
                  <p class="card-category"> Here you can View Student details</p>
                </div>
                <div class="card-body">
                 <form action="Student.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                       <!--  <div class="form-group"> -->
                           <div class="form-group">
                              <img  width="140" height="40" class="img img-thumbnail " src="../student_images/<?=$row['photo']?>" algin="margin-left">
                           </div>
                         </div>
                         <div class="row">
                           <div class="col-md-6">
                          <div class="form-group">
                          <label class="bmd-label-floating">Status</label>
                          <input type="text" class="form-control" name="Status" disabled="" value="<?=$row['Status']?>">
                        </div>
                      </div>
                        <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Passout</label>
                          <input type="text" class="form-control" name="passout" disabled="" value="<?=$row['passout']?>">
                        </div>
                      </div>
                        </div>
                        <div class="row">
                        <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Enrollment no.</label>
                          <input type="text" class="form-control" name="enrollment_no" disabled="" value="<?=$row['enrollment_no']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="first_name" disabled="" value="<?=$row['first_name']?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="last_name" disabled="" value="<?=$row['last_name']?>">
                        </div>
                      </div>
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">S/D/W Of</label>
                          <input type="text" class="form-control" name="p_name" disabled="" value="<?=$row['p_name']?>">
                        </div>
                      </div>
                        <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Parent's Contact no.</label>
                          <input type="text" class="form-control" name="p_no" disabled="" value="<?=$row['p_no']?>">
                        </div>
                      </div>
                       <div class="col-md-3">
                        <div class="form-group">
                           <label class="bmd-label-floating">Gender</label>
                          <div class="form-check" style="    display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" disabled="" name="gender" value="Male" <?php if($row['gender']=='Male'){ echo "checked";} ?>> Male
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" disabled="" name="gender" value="Female" <?php if($row['gender']=='Female'){ echo "checked";} ?>> Female
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                     </div >
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">DOB</label>
                          <input type="date" class="form-control" name="DOB" disabled="" value="<?=$row['DOB']?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile no.</label>
                          <input type="text" class="form-control" name="Mobile_no" disabled="" value="<?=$row['Mobile_no']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Address</label>
                          <input type="email" class="form-control" name="Email_id" disabled="" value="<?=$row['Email_id']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Branch</label>
                            <input type="text" class="form-control" name="" disabled="" value="<?=$row['Department_name']?>">
                          <!-- <select class="form-control" name="Branch">
                            <?php while ($row1=mysqli_fetch_assoc($ed)) { ?>
                              <option value="<?=$row1['Department_Id']?>"><?=$row1['Department_name']?></option>
                            <?php } ?>
                            
                          </select> -->
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Semester</label>
                          <input type="text" class="form-control" name="Sem" disabled="" value="<?=$row['Sem']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Caste</label>
                          <input type="text" class="form-control" name="Caste" disabled="" value="<?=$row['Caste']?>">
                        </div>
                      </div>
                    </div>
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Permanent Address</label>
                          <input type="text" class="form-control" name="Per_address" disabled="" value="<?=$row['Per_address']?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Temporary Address</label>
                          <input type="text" class="form-control" name="tem_address" disabled="" value="<?=$row['tem_address']?>">
                        </div>
                      </div>
                     </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">District</label>
                          <input type="text" class="form-control" name="district" disabled="" value="<?=$row['district']?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Block</label>
                          <input type="text" class="form-control" name="block" disabled="" value="<?=$row['block']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Pin Code</label>
                          <input type="text" class="form-control" name="pincode" disabled="" value="<?=$row['pincode']?>">
                        </div>
                         </div> 
                         </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">10th Percentage</label>
                          <input type="text" class="form-control" name="ten" disabled="" value="<?=$row['ten']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">12th Percentage</label>
                          <input type="text" class="form-control" name="twelve" disabled="" value="<?=$row['twelve']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">CGPA till Date</label>
                          <input type="text" class="form-control" name="cgpa" disabled="" value="<?=$row['cgpa']?>">
                        </div>
                      </div>
                   </div>
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem1 Sgpa</label>
                          <input type="text" class="form-control" name="sem1_sgpa" disabled="" value="<?=$row['sem1_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem2 Sgpa</label>
                          <input type="text" class="form-control" name="sem2_sgpa" disabled="" value="<?=$row['sem2_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem3 Sgpa</label>
                          <input type="text" class="form-control" name="sem3_sgpa" disabled="" value="<?=$row['sem3_sgpa']?>">
                        </div>
                      </div>
                     </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem4 Sgpa</label>
                          <input type="text" class="form-control" name="sem4_sgpa" disabled="" value="<?=$row['sem4_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem5 Sgpa</label>
                          <input type="text" class="form-control" name="sem5_sgpa" disabled="" value="<?=$row['sem5_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem6 Sgpa</label>
                          <input type="text" class="form-control" name="sem6_sgpa" disabled="" value="<?=$row['sem6_sgpa']?>">
                        </div>
                        </div> 
                        </div>
                     </div >
              </div>
            </div>
          </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php include("include/footer.php"); ?>