<?php include("include/header.php"); 
// if(isset($_GET['appsub_del_id'])){
//   $del=mysqli_query($con,"delete from subject where sub_id=$_GET[appsub_del_id]");
//   if($del){
//     echo "selected row is deleted";
//   }else{
//     echo "error in deleting the row";
//   }
// }
if(isset($_POST['doc_edit_id'])){
  $edit=mysqli_query($con," update document_details set doc_name='$_POST[doc_name]',doc_type='$_POST[doc_type]',doc_desc='$_POST[doc_desc]' where doc_id=$_POST[doc_edit_id]");
  if($edit){
    echo "selected row is deleted";
  }else{
    echo "error in deleting the row";
  }
}
 $result=mysqli_query($con,"select * from doc_details");
echo mysqli_error($con);
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Document Details</h4>
                  <p class="card-category"> Here you get all Document Details</p>
                  <a href="doc_add.php" class="btn btn-warning btn-sm active">Add</a>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-danger">
                        <tr>
                          <th>#</th>
                          <th>Document Name</th>
                          <th>Document type</th>
                          <th>Description</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      </tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['doc_id']?></td>
                          <td><?=$r['doc_name']?></td>
                          <td><?=$r['doc_type']?></td>
                          <td><?=$r['doc_desc']?></td>
                          <td>
                            <a href="doc_edit.php?doc_edit_id=<?=$r['doc_id']?>" class="btn btn-primary btn-sm btn-round">Edit</a>
                            <a href="doc_view.php?doc_view_id=<?=$r['doc_id']?>" class="btn btn-danger btn-sm btn-round">View</a>
                            <a href="<?=$r['doc_id']?>" class="btn btn-danger btn-sm btn-round">Download</a>
                          </td>
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>