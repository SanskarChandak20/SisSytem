<?php 

include ("include/header.php"); 
  $result=mysqli_query($con,"select * from department");
  $s=mysqli_query($con,"select * from session");
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Add New Student Detail</h4>
                  <p class="card-category"> Here you can Add New Student details</p>
                </div>
                <div class="card-body">
                  <form method="post" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <?php
                          if(isset($_POST['student_details'])){
                            $Status = mysqli_real_escape_string($con, $_POST['Status']);
                            $enrollment_no = mysqli_real_escape_string($con, $_POST['enrollment_no']);
                            $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
                            $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
                            $DOB = mysqli_real_escape_string($con, $_POST['DOB']);
                            $p_name = mysqli_real_escape_string($con, $_POST['p_name']);
                            $gender = mysqli_real_escape_string($con, $_POST['gender']);
                            $Branch = mysqli_real_escape_string($con, $_POST['Branch']);
                            $Sem = mysqli_real_escape_string($con, $_POST['Sem']);
                            $Caste = mysqli_real_escape_string($con, $_POST['Caste']);
                            $Mobile_no= mysqli_real_escape_string($con, $_POST['Mobile_no']);
                            $Email_id = mysqli_real_escape_string($con, $_POST['Email_id']);
                            $p_no= mysqli_real_escape_string($con, $_POST['p_no']);
                            $ten= mysqli_real_escape_string($con, $_POST['ten']);
                            $twelve = mysqli_real_escape_string($con, $_POST['twelve']);
                            $sem1_sgpa= mysqli_real_escape_string($con, $_POST['sem1_sgpa']);
                            $sem2_sgpa= mysqli_real_escape_string($con, $_POST['sem2_sgpa']);
                            $sem3_sgpa= mysqli_real_escape_string($con, $_POST['sem3_sgpa']);
                            $sem4_sgpa= mysqli_real_escape_string($con, $_POST['sem4_sgpa']);
                            $sem5_sgpa= mysqli_real_escape_string($con, $_POST['sem5_sgpa']);
                            $sem6_sgpa= mysqli_real_escape_string($con, $_POST['sem6_sgpa']);
                            $cgpa= mysqli_real_escape_string($con, $_POST['cgpa']);
                            $Per_address = mysqli_real_escape_string($con, $_POST['Per_address']);
                            $tem_address = mysqli_real_escape_string($con, $_POST['tem_address']);
                            $block= mysqli_real_escape_string($con, $_POST['block']);
                            $district = mysqli_real_escape_string($con, $_POST['district']);
                            $pincode = mysqli_real_escape_string($con, $_POST['pincode']);
                            $session = mysqli_real_escape_string($con, $_POST['session']);
                            $photo=$_FILES['photo']['name'];
                            $sql = "INSERT INTO `student_details` (`Status`, `photo`, `enrollment_no`, `first_name`, `last_name`, `DOB`, `p_name`, `gender`, `Branch`, `Sem`, `Caste`, `Mobile_no`, `Email_id`, `p_no`, `ten`, `twelve`, `sem1_sgpa`, `sem2_sgpa`, `sem3_sgpa`, `sem4_sgpa`, `sem5_sgpa`, `sem6_sgpa`, `cgpa`, `Per_address`, `tem_address`, `block`, `district`, `pincode`,`session`,`passout`) VALUES ('$Status', '$photo', '$enrollment_no', '$first_name', '$last_name', '$DOB', '$p_name', '$gender', '$Branch', '$Sem', '$Caste', '$Mobile_no', '$Email_id', '$p_no', '$ten', '$twelve', '$sem1_sgpa', '$sem2_sgpa', '$sem3_sgpa', '$sem4_sgpa', '$sem5_sgpa', '$sem6_sgpa',      '$cgpa', '$Per_address', '$tem_address', '', '$block', '$district', '$pincode','$session')";
                            if(mysqli_query($con, $sql)){
                                move_uploaded_file($_FILES['photo']['tmp_name'],'../student_images/'.$photo);
                              // echo "Records added successfully.";
                             } else{
                             mysqli_error($con);
                            }
                           }
                          ?>
                            <div class="form-check">
                              <label class="bmd-label-floating">Status</label>
                              <label class="form-check-label" style="display: inline-block;margin-left: 20px;">
                                <input class="form-check-input" type="radio" name="Status" value="Regular" checked=""> Regular
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="Status" value="EX" checked=""> EX
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                            </div>
                            <div class="form-group">
                              <label class="bmd-label-floating">Photo</label>
                              <input class="form-control" type="file" name="photo" >
                           </div>
                        </div>
                        <div class="form-group">
                          <label class="bmd-label-floating">Enrollment no.</label>
                          <input type="text" class="form-control" name="enrollment_no">
                        </div>
                      </div>

                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="first_name">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="last_name">
                        </div>
                      </div>
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">S/D/W Of</label>
                          <input type="text" class="form-control" name="p_name">
                        </div>
                      </div>
                        <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Parent's Contact no.</label>
                          <input type="text" class="form-control" name="p_no">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                           <label class="bmd-label-floating">gender</label>
                          <div class="form-check" style="display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="gender" value="Male" checked=""> Male
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="gender" value="Female" checked=""> Female
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">DOB</label>
                          <input type="date" class="form-control" name="DOB">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile no.</label>
                          <input type="text" class="form-control" name="Mobile_no">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Address</label>
                          <input type="email" class="form-control" name="Email_id">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Branch</label>
                          <select class="form-control" name="Branch">
                            <?php while ($row=mysqli_fetch_assoc($result)) { ?>
                              <option value="<?=$row['Department_Id']?>"><?=$row['Department_name']?></option>
                            <?php } ?>
                            
                          </select>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Semester</label>
                          <input type="text" class="form-control" name="Sem">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Caste</label>
                          <input type="text" class="form-control" name="Caste">
                        </div>
                      </div>
                    </div>
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Permanent Address</label>
                          <input type="text" class="form-control" name="Per_address">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Temporary Address</label>
                          <input type="text" class="form-control" name="tem_address">
                        </div>
                      </div>
                     </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">District</label>
                          <input type="text" class="form-control" name="district">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Block</label>
                          <input type="text" class="form-control" name="block">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Pin Code</label>
                          <input type="text" class="form-control" name="pincode">
                        </div>
                         </div> 
                         </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">10th Percentage</label>
                          <input type="text" class="form-control" name="ten">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">12th Percentage</label>
                          <input type="text" class="form-control" name="twelve">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">CGPA till Date</label>
                          <input type="text" class="form-control" name="cgpa">
                        </div>
                      </div>
                   </div>
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem1 Sgpa</label>
                          <input type="text" class="form-control" name="sem1_sgpa">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem2 Sgpa</label>
                          <input type="text" class="form-control" name="sem2_sgpa">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem3 Sgpa</label>
                          <input type="text" class="form-control" name="sem3_sgpa">
                        </div>
                      </div>
                     </div>
                    <div class="row">
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem4 Sgpa</label>
                          <input type="text" class="form-control" name="sem4_sgpa">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem5 Sgpa</label>
                          <input type="text" class="form-control" name="sem5_sgpa">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem6 Sgpa</label>
                          <input type="text" class="form-control" name="sem6_sgpa">
                        </div>
                        </div> 
                        <div class="col-md-3">
                          <div class="form-group">
                          <label class="bmd-label-floating">Session</label>
                          <select class="form-control" name="session">
                            <?php while ($row=mysqli_fetch_assoc($s)) { ?>
                              <option value="<?=$row['session_id']?>"><?=$row['session_name']?></option>
                          <?php } ?>
                          </select>
                        </div>
                        </div>
                        <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" class="btn btn-danger btn-sm btn-danger" name="student_details">
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include ("include/footer.php"); ?>