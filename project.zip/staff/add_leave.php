<?php include ("include/header.php"); 
  $result=mysqli_query($con,"select * from staff_details where dep=$_SESSION[bid]");
  $user_type="staff";//student
  $s=mysqli_query($con,"select * from subject");
 $r=mysqli_query($con,"select * from department");
   // $r=mysqli_query($con,"select * from staff_post");
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Apply for leave Application</h4>
                  <p class="card-category"> Here you can Apply for leave Application</p>
                </div>
                <div class="card-body">
                  <form method="post" action="add_leave.php">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <?php
                          
                          if(isset($_POST['leave_app'])){
                            mysqli_query($con, "INSERT INTO `app_leave` (`to_id`, `app_subject`, `message`, `from_id`) VALUES ('$_POST[to_id]','$_POST[sub]','$_POST[message]','$_POST[form_id]')");
                           }
                          ?>
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">To</label>
                          <select class="form-control" name="Branch">
                            <?php while ($row=mysqli_fetch_assoc($result)) { ?>
                              <option value="<?=$row['staff_id']?>"><?=$row['first_name']?></option>
                            <?php } ?>
                            
                          </select>
                           <!-- <select class="form-control" name="to_id">
                           <?php while ($row=mysqli_fetch_assoc($result)) {?>
                            <option value="<?=$row['staff_id']?>"><?=$row['first_name']?></option>
                          <?php } ?>
                         </select> -->
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Subject</label>
                         <select class="form-control" name="sub">
                           <?php while ($row=mysqli_fetch_assoc($s)) {?>
                            <option value="<?=$row['sub_id']?>"><?=$row['sub_name']?></option>
                          <?php } ?>
                         </select>
                        </div>
                      </div>
                        <input type="hidden" class="form-control" name="form_id" value="1" >  
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Message</label>
                          <textarea rows="10" class="form-control" name="message"></textarea>
                        </div>
                      </div>
                       <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit"  value="submit" name="leave_app" class="btn btn-danger btn-sm btn-danger">
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include ("include/footer.php"); ?>