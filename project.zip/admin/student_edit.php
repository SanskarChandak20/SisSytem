<?php include("include/header.php"); 
$ed=mysqli_query($con,"select * from department");
if(isset($_GET["std_edit_id"])){
  $result=mysqli_query($con,"select * from student_details where s_id=$_GET[std_edit_id]");
  $row=mysqli_fetch_assoc($result);
   $s1=mysqli_query($con,"select * from sem");
  $c=mysqli_query($con,"select * from caste");
 // print_r($row);
}
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Edit Student Detail</h4>
                  <p class="card-category"> Here you can Edit Student details</p>
                </div>
                <div class="card-body">
                  <form action="Student.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                        <div class="form-check">
                           <input type="hidden" class="form-control" name="S_id" value="<?=$row['S_id']?>">
                              <label class="bmd-label-floating">Status</label>
                              <label class="form-check-label" style="display: inline-block;margin-left: 20px;">
                                <input class="form-check-input" type="radio" name="Status" value="Regular"  <?php if($row['Status']=='Regular'){ echo "checked";} ?>>Regular
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="Status"  value="EX"  <?php if($row['Status']=='EX'){ echo "checked";} ?>> EX
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                            </div>
                            <div class="form-group">
                              <label class="bmd-label-floating">Photo</label>
                              <div class="form-group">
                              <img  width="140" height="40" class="img img-thumbnail " src="../student_images/<?=$row['photo']?>">
                               </div>
                              <input class="form-control" type="file" name="photo" value="<?=$row['photo']?>">
                           </div>
                        </div>
                        <div class="form-group">
                          <label class="bmd-label-floating">Enrollment no.</label>
                          <input type="text" class="form-control" name="enrollment_no" value="<?=$row['enrollment_no']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control" name="first_name" value="<?=$row['first_name']?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="text" class="form-control" name="last_name" value="<?=$row['last_name']?>">
                        </div>
                      </div>
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">S/D/W Of</label>
                          <input type="text" class="form-control" name="p_name" value="<?=$row['p_name']?>">
                        </div>
                      </div>
                        <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Parent's Contact no.</label>
                          <input type="text" class="form-control" name="p_no" value="<?=$row['p_no']?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                           <label class="bmd-label-floating">Gender</label>
                          <div class="form-check" style="display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" value="Male" type="radio" name="gender" <?php if($row['gender']=='Male'){ echo "checked";} ?>> Male <!-- <?php echo $row['gender']; ?> --> 
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" value="Female" type="radio" name="gender" <?php if($row['gender']=='Female'){ echo "checked";} ?>> Female
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">DOB</label>
                          <input type="date" class="form-control" name="DOB" value="<?=$row['DOB']?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile no.</label>
                          <input type="text" class="form-control" name="Mobile_no" value="<?=$row['Mobile_no']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Address</label>
                          <input type="email" class="form-control" name="Email_id" value="<?=$row['Email_id']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Branch</label>
                          <select class="form-control" name="Branch">
                            <?php while ($row1=mysqli_fetch_assoc($ed)) { ?>
                              <option value="<?=$row1['Department_Id']?>" <?php if($row1['Department_Id']==$row['Branch']){ echo "selected";} ?>><?=$row1['Department_name']?></option>
                            <?php } ?>
                          </select>  
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Semester</label>
                          <!-- <input type="text" class="form-control" name="Sem" value="<?=$row['Sem']?>"> -->
                          <select class="form-control" name="Sem">
                            <?php while ($row2=mysqli_fetch_assoc($s1)) { ?>
                              <option value="<?=$row1['semid']?>" <?php if($row2['semid']==$row['Sem']){ echo "selected";} ?>><?=$row2['semname']?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Caste</label>
                          <!-- <input type="text" class="form-control" name="Caste" value="<?=$row['Caste']?>"> -->
                          <select class="form-control" name="Caste">
                            <?php while ($row3=mysqli_fetch_assoc($c)) { ?>
                              <option value="<?=$row3['cid']?>" <?php if($row3['cid']==$row['Caste']){ echo "selected";} ?>><?=$row3['cname']?></option>
                            <?php } ?>
                          </select>
                        </div>
                      </div>
                    </div>
                     <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Permanent Address</label>
                          <input type="text" class="form-control" name="Per_address" value="<?=$row['Per_address']?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Temporary Address</label>
                          <input type="text" class="form-control" name="tem_address" value="<?=$row['tem_address']?>">
                        </div>
                      </div>
                     </div>
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">District</label>
                          <input type="text" class="form-control" name="district" value="<?=$row['district']?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Block</label>
                          <input type="text" class="form-control" name="block" value="<?=$row['block']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Pin Code</label>
                          <input type="text" class="form-control" name="pincode" value="<?=$row['pincode']?>">
                        </div>
                         </div> 
                         </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">10th Percentage</label>
                          <input type="text" class="form-control" name="ten" value="<?=$row['ten']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">12th Percentage</label>
                          <input type="text" class="form-control" name="twelve" value="<?=$row['twelve']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">CGPA till Date</label>
                          <input type="text" class="form-control" name="cgpa" value="<?=$row['cgpa']?>">
                        </div>
                      </div>
                   </div>
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem1 Sgpa</label>
                          <input type="text" class="form-control" name="sem1_sgpa" value="<?=$row['sem1_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem2 Sgpa</label>
                          <input type="text" class="form-control" name="sem2_sgpa" value="<?=$row['sem2_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem3 Sgpa</label>
                          <input type="text" class="form-control" name="sem3_sgpa" value="<?=$row['sem3_sgpa']?>">
                        </div>
                      </div>
                     </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem4 Sgpa</label>
                          <input type="text" class="form-control" name="sem4_sgpa" value="<?=$row['sem4_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem5 Sgpa</label>
                          <input type="text" class="form-control" name="sem5_sgpa" value="<?=$row['sem5_sgpa']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Sem6 Sgpa</label>
                          <input type="text" class="form-control" name="sem6_sgpa" value="<?=$row['sem6_sgpa']?>">
                        </div>
                        </div> 
                         <div class="col-md-3">
                        <div class="form-group">
                           <label class="bmd-label-floating">Passout</label>
                          <div class="form-check" style="display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="passout"  value="deactive" <?php if($row['passout']=='active'){ echo "checked";} ?>> Yes
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="passout" value="active" <?php if($row['passout']=='active'){ echo "checked";} ?>> No
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                      </div>
                        <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" class="btn btn-danger btn-sm btn-danger" name="student_details">
                        </div> 
                      </div>  
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>