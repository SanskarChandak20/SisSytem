<?php include("include/header.php");
if(isset($_GET["app_view_id"])){
  $result=mysqli_query($con,"select * from app_leave join subject on app_leave.app_subject=subject.sub_id where l_id=$_GET[app_view_id]");
  $result1=mysqli_query($con,"select * from app_leave join student_details on app_leave.from_id=student_details.first_name where l_id=$_GET[app_view_id]");
  $row=mysqli_fetch_assoc($result);
  $row1=mysqli_fetch_assoc($result1);
}
 ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">View Application Detail</h4>
                  <p class="card-category"> Here you can View Application details</p>
                </div>
                <div class="card-body">
                  <form action="leave_app.php" method="post">
                    <div class="row">
                      <div class="col-md-6">
                       <div class="form-group">
                          <label class="bmd-label-floating"> To</label>
                          <input type="text" class="form-control" readonly="" name="to_id" value="<?=$row['to_id']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Subject</label>
                          <input type="text" class="form-control" name="" readonly="" value="<?=$row['sub_name']?>">
                        </div>
                      </div>
                  </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Message</label>
                          <input type="text" class="form-control" readonly="" name="message" value="<?=$row['message']?>">
                        </div>
                      </div>
                     </div >
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">From</label>
                          <input type="text" class="form-control" readonly="" name="from" value="<?=$row1['']?>" >
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Time</label>
                          <input type="text" class="form-control" readonly="" name="time"  value="<?=$row['time']?>">
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
