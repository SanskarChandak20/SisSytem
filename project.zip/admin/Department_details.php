<?php include("include/header.php"); 
if(isset($_GET['dep_del_id'])){
  $del=mysqli_query($con,"delete from department where Department_Id=$_GET[dep_del_id]");
  if($del){?>
            <div class="content">
            <div class="alert alert-success"> 
                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Records deleted successfully";?></span>
                                  </div>
                            <?php  
                             }else{ ?>
                              
                                  <div class="alert alert-Danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Error in deleting";?></span>
                                  </div>
                                  </div>?>
                            <?php }
}
if(isset($_POST['dep_edit_id'])){
  $edit="update department set Department_name='$_POST[Department_name]' where Department_Id=$_GET[dep_edit_id]";
  if(mysqli_query($con,$edit)){?>
            <div class="content">
            <div class="alert alert-success"> 
                             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Update successfully";?></span>
                                  </div>
                            <?php  
                             }else{ ?>
                              
                                  <div class="alert alert-Danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Error in updateing";?></span>
                                  </div>
                                  </div>
                            <?php }
}
 $result=mysqli_query($con,"select * from department");
echo mysqli_error($con);
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">All Department Details</h4>
                  <p class="card-category"> Here you get all Department details</p>
                  <a href="department_add.php" class="btn btn-warning btn-sm active"><i class="material-icons">add_circle_outline</i></a>
                </div>
                <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="department">
                      <thead class=" text-danger">
                        <tr>
                          <th>Department Id</th>
                          <th>Department  Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['Department_Id']?></td>
                          <td><?=$r['Department_name']?></td>
                          <td>
                            <a href="department_edit.php?dep_edit_id=<?=$r['Department_Id']?>"class="btn btn-warning btn-fab"><i class="material-icons">create</i></a>
                            <a href="Department_view.php?dep_view_id=<?=$r['Department_Id']?>" class="btn btn-info btn-fab"><i class="material-icons">visibility</i></a>
                            <a href="department_details.php?dep_del_id=<?=$r['Department_Id']?>"class="btn btn-rose btn-fab"><i class="material-icons">delete</i></a>
                         </td> 
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
    $(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#department').DataTable();
  });
  </script>