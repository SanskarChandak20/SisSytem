<?php include("include/header.php"); 
if(isset($_GET['ses_del_id'])){
  $del=mysqli_query($con,"delete from session where session_id=$_GET[ses_del_id]");
  if($del){
    echo "selected row is deleted";
  }else{
    echo "error in deleting the row";
  }
}
if(isset($_POST['ses_edit'])){
  $edit=mysqli_query($con," update session set session_name='$_POST[session_name]' where session_id=$_POST[session_id]");
  if($edit){
    //echo "selected row is deleted";
  }else{
    //echo "error in deleting the row";
  }
}
 $result=mysqli_query($con,"select * from session");
echo mysqli_error($con);
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Session Details</h4>
                  <p class="card-category"> Here you get all Session details</p>
                  <a href="./session_add.php" class="btn btn-warning btn-sm active">Add</a>
                </div>
                <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="session">
                      <thead class=" text-danger">
                        <tr>
                          <th>Session Id</th>
                          <th>Session  Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['session_id']?></td>
                          <td><?=$r['session_name']?></td>
                          <td>
                            <a href="session_edit.php?ses_edit_id=<?=$r['session_id']?>" class="btn btn-warning btn-fab"><i class="material-icons">create</i></a>
                            <a href="session_details.php?ses_del_id=<?=$r['session_id']?>"class="btn btn-rose btn-fab"><i class="material-icons">delete</i></a>
                          </td>
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
    $(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#session').DataTable();
  });
  </script>