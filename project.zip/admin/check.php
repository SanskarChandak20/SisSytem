<?php include("include/database.php");  
session_start();
if(isset($_POST['submit'])){  
 $result=mysqli_query($con,"select * from user where user_name='$_POST[username]' and password='$_POST[password]'");
 $row=mysqli_fetch_assoc($result);
 if($result->num_rows>0){
 	if($row['user_type']=='admin'){

 	}elseif($row['user_type']=='student'){

 	}elseif($row['user_type']=='staff'){

 	}
 }else{
 	$_SESSION['error']="INVALID USER NAME OR PASSWORD";
 	header("location:login.php");
 }
}
?>