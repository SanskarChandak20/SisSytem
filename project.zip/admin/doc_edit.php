<?php include("include/header.php"); 
if(isset($_GET["doc_edit_id"])){
  $result=mysqli_query($con,"select * from doc_details where doc_id=$_GET[doc_edit_id]");
  $row=mysqli_fetch_assoc($result);
}
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Edit Document Detail</h4>
                  <p class="card-category"> Here you can Edit Application Subject detail</p>
                </div>
                <div class="card-body">
                  <form action="doc_details.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating"> Document Name</label>
                          <input type="text" class="form-control" readonly="" name="doc_name" value="<?=$row['doc_name']?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Document type</label>
                          <input type="text" class="form-control" name="doc_type" value="<?=$row['doc_type']?>">
                        </div>
                      </div>
                        <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Document Descripition</label>
                          <input type="text" class="form-control" name="doc_desc" value="<?=$row['doc_desc']?>">
                        </div>
                        </div>
                        <div class="col-md-3">
                              <label class="bmd-label-floating">Document Upload</label>
            
                              <input class="form-control" type="file" name="document" >
                           </div>
                         <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" name="doc_edit" class="btn btn-danger btn-sm btn-danger">
                         </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>