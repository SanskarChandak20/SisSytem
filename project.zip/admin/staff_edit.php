<?php include("include/header.php"); 
$ed=mysqli_query($con,"select * from department");
if(isset($_GET["stf_edit_id"])){
  $result=mysqli_query($con,"select * from staff_details where staff_id=$_GET[stf_edit_id]");
  $row=mysqli_fetch_assoc($result);
}
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Edit the Staff Detail</h4>
                  <p class="card-category"> Here you can Edit New Staff details</p>
                </div>
                <div class="card-body">
                  <form action=" staff_details.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                      <div class="form-group">
                        <input name="staff_id" value="<?=$row['staff_id']?>" hidden>
                              <label class="bmd-label-floating">Photo</label>
                              <div class="form-group">
                              <img  width="140" height="40" class="img img-thumbnail " src="../staff_images/<?=$row['photo']?>">
                               </div>
                              <input class="form-control" type="file" name="photo" value="<?=$row['photo']?>">
                           </div>
                           </div>  
                      <div class="row">         
                      <div class="col-md-6">
                       <div class="form-group">
                          <label class="bmd-label-floating"> First Name</label>
                          <input type="text" class="form-control" name="first_name" value="<?=$row['first_name']?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"> Last Name</label>
                          <input type="text" class="form-control" name="last_name" value="<?=$row['last_name']?>">
                        </div>
                      </div>
                  </div>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">S/D/W Of</label>
                          <input type="text" class="form-control" name="p_name" value="<?=$row['p_name']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                           <label class="bmd-label-floating">Gender</label>
                          <div class="form-check" style="    display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="gender" value="Male" <?php if($row['gender']=='Male'){ echo "checked";} ?>> Male
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="gender" value="Female" <?php if($row['gender']=='Female'){ echo "checked";} ?>> Female
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">DOB</label>
                          <input type="date" class="form-control" name="DOB"  value="<?=$row['DOB']?>" >
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile no.</label>
                          <input type="text" class="form-control" name="mobile_number"  value="<?=$row['mobile_number']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Address</label>
                          <input type="email" class="form-control"  name="email_id"  value="<?=$row['email_id']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Department</label>
                         <select class="form-control" name="dep">
                            <?php while ($row1=mysqli_fetch_assoc($ed)) { ?>
                              <option value="<?=$row1['Department_Id']?>" <?php if($row1['Department_Id']==$row['dep']){ echo "selected";} ?>><?=$row1['Department_name']?></option>
                            <?php } ?>
                            
                          </select>   
                          </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Qualification</label>
                          <input type="text" class="form-control"  name="qualification"  value="<?=$row['qualification']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Designation</label>
                          <input type="text" class="form-control" name="designation"  value="<?=$row['designation']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address</label>
                          <input type="text" class="form-control" name="address"  value="<?=$row['address']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">District</label>
                          <input type="text" class="form-control" name="district"  value="<?=$row['district']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Block</label>
                          <input type="text" class="form-control" name="block"  value="<?=$row['block']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Pin Code</label>
                          <input type="text" class="form-control" name="pincode" value="<?=$row['pincode']?>">
                        </div>
                        <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" class="btn btn-danger btn-sm btn-danger" name="stf_edit">
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
  