-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2019 at 11:18 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sdbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Department_Id` int(11) NOT NULL,
  `Department_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Department_Id`, `Department_name`) VALUES
(1, 'Civil Engineering'),
(2, 'Computer Science Engineering'),
(3, 'Electrical Engineering'),
(4, 'Electronics And Telecommunication'),
(5, 'Mechanical Engineering'),
(6, 'Modern Office Management'),
(7, 'Refrigeration and air conditioning');

-- --------------------------------------------------------

--
-- Table structure for table `staff_detail`
--

CREATE TABLE `staff_detail` (
  `staff_id` int(12) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `First Name` varchar(15) NOT NULL,
  `Last Name` text NOT NULL,
  `S/D/W of` text NOT NULL,
  `mobile_number` int(10) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `department` varchar(15) NOT NULL,
  `qualification` varchar(10) NOT NULL,
  `designation` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `Status` tinyint(1) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `S_id` int(15) NOT NULL,
  `enrollment_no` varchar(100) NOT NULL,
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `DOB` varchar(100) NOT NULL,
  `S/D/W_of` varchar(30) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Branch` varchar(20) NOT NULL,
  `Sem` tinyint(1) NOT NULL,
  `Caste` varchar(10) NOT NULL,
  `Mobile_no.` varchar(10) NOT NULL,
  `Email_id` varchar(30) NOT NULL,
  `parent's_no` varchar(10) NOT NULL,
  `10th` int(5) NOT NULL,
  `12th` int(5) NOT NULL,
  `sem1_sgpa` int(5) NOT NULL,
  `sem2_sgpa` int(5) NOT NULL,
  `sem3_sgpa` int(5) NOT NULL,
  `sem4_sgpa` int(5) NOT NULL,
  `sem5_sgpa` int(5) NOT NULL,
  `sem6_sgpa` int(5) NOT NULL,
  `cgpa _till_date` int(5) NOT NULL,
  `Per_address` varchar(50) NOT NULL,
  `tem_address` varchar(50) NOT NULL,
  `post` varchar(25) NOT NULL,
  `block` varchar(25) NOT NULL,
  `district` varchar(25) NOT NULL,
  `pincode` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`Status`, `photo`, `S_id`, `enrollment_no`, `first_name`, `last_name`, `DOB`, `S/D/W_of`, `Gender`, `Branch`, `Sem`, `Caste`, `Mobile_no.`, `Email_id`, `parent's_no`, `10th`, `12th`, `sem1_sgpa`, `sem2_sgpa`, `sem3_sgpa`, `sem4_sgpa`, `sem5_sgpa`, `sem6_sgpa`, `cgpa _till_date`, `Per_address`, `tem_address`, `post`, `block`, `district`, `pincode`) VALUES
(0, '', 2, '16022c03021', 'Dishant', 'choure', '9-11-2000', 'Mr.rajesh choure', 'male', 'civil', 6, 'General', '9617530716', 'chouredishant09@gmail.com', '992666310', 78, 0, 8, 8, 8, 8, 8, 0, 8, 'Shiv colony,neavli road sendhwa', 'Padam kund ward,khandwa', '', '', 'Barwani', '451666'),
(0, '', 3, '16022c03017', 'Bhavesh', 'Malakar', '28-9-1998', 'Mr.Gourishankar Malakar', 'male', 'civil', 6, 'OBC', '9177586615', 'malakarb01@gmail.com', '7869592636', 71, 64, 7, 7, 7, 8, 8, 0, 8, 'Selltax Colony Khandwa', 'Selltax Colony Khandwa', '', '', '', ''),
(0, '', 4, '16022c03024', 'Hariom ', 'Malakar', '3-5-1999', 'Mr.ram krishna malakar', 'male', 'civil', 6, 'OBC', '7415001432', 'ommalakar06067@gmail.com', '9424025992', 61, 50, 7, 6, 7, 7, 7, 0, 7, 'pokar kalan post-bhagwan pura', 'obc hostel,khandwa', '', '', '', ''),
(0, '', 5, '16022c03037', 'Prithiv', 'Waskel', '22-5-2002', 'Mr.Chhotu Singh Waskel', 'male', 'civil', 6, 'ST', '9589165569', 'prithivwaskel@gmail.com', '9165564731', 85, 0, 8, 8, 8, 8, 9, 0, 8, 'Village-Dabhad', 'College Boys Hostel', 'Pagar', 'Umarband', 'Dhar', '454449');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(12) NOT NULL,
  `user_name` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(12) NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Department_Id`);

--
-- Indexes for table `staff_detail`
--
ALTER TABLE `staff_detail`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`S_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `Department_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `staff_detail`
--
ALTER TABLE `staff_detail`
  MODIFY `staff_id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `student_details`
--
ALTER TABLE `student_details`
  MODIFY `S_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(12) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
