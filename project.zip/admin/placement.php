<?php 
include("include/header.php");
if (isset($_GET['std_del_id'])){
 $del=mysqli_query($con,"delete from student_details where S_id=$_GET[std_del_id]");  

 if($del){?>

 <div class="content">
 <div class="alert alert-success">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<i class="material-icons">close</i>
</button>
<span><?php echo "Records deleted successfully";?></span>
</div>
<?php  
}else{ ?>
 <div class="alert alert-Danger">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<i class="material-icons">close</i>
</button>
<span><?php echo "Error in deleting";?></span>
</div>
</div>?>
 <?php }
}
if(isset($_POST['student_details'])){
  // print_r($_FILES);
  $photo=$_FILES['photo']['name'];
  if ($photo=='') {
   $edit=mysqli_query($con,"update student_details set Status='$_POST[Status]',enrollment_no='$_POST[enrollment_no]',first_name='$_POST[first_name]',last_name='$_POST[last_name]',p_name='$_POST[p_name]',p_no='$_POST[p_no]',gender='$_POST[gender]',DOB='$_POST[DOB]',Mobile_no='$_POST[Mobile_no]',Email_id='$_POST[Email_id]',Branch='$_POST[Branch]',Sem='$_POST[Sem]',Caste='$_POST[Caste]',Per_address='$_POST[Per_address]',tem_address='$_POST[tem_address]',district='$_POST[district]',block='$_POST[block]',pincode='$_POST[pincode]',ten='$_POST[ten]',twelve='$_POST[twelve]',cgpa='$_POST[cgpa]',sem1_sgpa='$_POST[sem1_sgpa]',sem2_sgpa='$_POST[sem2_sgpa]',sem3_sgpa='$_POST[sem3_sgpa]',sem4_sgpa='$_POST[sem4_sgpa]',sem5_sgpa='$_POST[sem5_sgpa]',sem6_sgpa='$_POST[sem6_sgpa]',passout='$_POST[passout]' where S_id=$_POST[S_id]");
    
  }else{
    $edit=mysqli_query($con,"update student_details set Status='$_POST[Status]',photo='$photo',enrollment_no='$_POST[enrollment_no]',first_name='$_POST[first_name]',last_name='$_POST[last_name]',p_name='$_POST[p_name]',p_no='$_POST[p_no]',gender='$_POST[gender]',DOB='$_POST[DOB]',Mobile_no='$_POST[Mobile_no]',Email_id='$_POST[Email_id]',Branch='$_POST[Branch]',Sem='$_POST[Sem]',Caste='$_POST[Caste]',Per_address='$_POST[Per_address]',tem_address='$_POST[tem_address]',district='$_POST[district]',block='$_POST[block]',pincode='$_POST[pincode]',ten='$_POST[ten]',twelve='$_POST[twelve]',cgpa='$_POST[cgpa]',sem1_sgpa='$_POST[sem1_sgpa]',sem2_sgpa='$_POST[sem2_sgpa]',sem3_sgpa='$_POST[sem3_sgpa]',sem4_sgpa='$_POST[sem4_sgpa]',sem5_sgpa='$_POST[sem5_sgpa]',sem6_sgpa='$_POST[sem6_sgpa]',passout='$_POST[passout]' where S_id=$_POST[S_id]");
      if(mysqli_query($con, $edit)){
          move_uploaded_file($_FILES['photo']['tmp_name'],'../student_images/'.$photo);
           //echo "Records added successfully.";
            }else{
           //echo mysqli_error($con);
              }}
if($edit){?>
   <!-- <? move_uploaded_file($_FILES['photo']['tmp_name'],'../staff_images/'.$photo);?> -->
                                   <div class="content">
                                   <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Records added successfully";?></span>
                                  </div>
                            <?php  
                             }else{ ?>
                                  <div class="alert alert-Danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Error in adding Staff";?></span>
                                  </div>
                                </div>
                            <?php }
                           }
 $result=mysqli_query($con,"select * from student_details join department on student_details.Branch= department.Department_Id where passout='Yes'");
echo mysqli_error($con);
  ?>
       <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">All Student Detail</h4>
                  <p class="card-category"> Here you can get all Student details</p>
                   <a href="student_add.php" class="btn btn-warning btn-sm active"><i class="material-icons">add_circle_outline</i></a>
                </div>
                <div>
                  <p class="card-header">Date/Time: <span id="datetime"></span></p>
                  <script>
                    var dt = new Date();
                    document.getElementById("datetime").innerHTML = dt.toLocaleString();
                  </script>
                </div>
                <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="student">
                      <thead class=" text-danger">
                        <tr>
                        <th>Name</th>
                        <th>Branch</th>
                        <th>Enrollment No.</th>
                        <th>Placement Detail</th>
                        <th>Studying Detail</th>
                        <th>Action</th>
                      </tr></thead>
                      <tbody>
                      
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['first_name']?></td>
                          <td><?=$r['Department_name']?></td>
                          <td><?=$r['enrollment_no']?></td>
                          <td><?=$r['placement _details']?></td>
                          <td><?=$r['studying_details']?></td>
                          <td>                    
                          <a href="Student_edit.php?std_edit_id=<?=$r['S_id']?>" class="btn btn-warning btn-fab"><i class="material-icons">create</i></a>
                        <a href="Student.php?std_del_id=<?=$r['S_id']?>" class="btn btn-rose btn-fab"><i class="material-icons">delete</i></a></td>
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 
<?php include("include/footer.php"); ?>
<!-- <script type="text/javascript" src="../assets/datatables.min.js"></script> -->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
  	$(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#student').DataTable();
  });
  </script>
