<?php include("include/header.php"); ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Add New Session</h4>
                  <p class="card-category"> Here you can Add New Session</p>
                </div>
                <div class="card-body">
                  <form method="post">
                    <div class="row">              
                      <div class="col-md-3">
                        <div class="form-group">
                          <?php 
                          if(isset($_POST['add_session'])){
                            $session_name= mysqli_real_escape_string($con, $_POST['session_name']);
                            $sql = "INSERT INTO session (session_name) VALUES ('$session_name')";
                            if(mysqli_query($con, $sql)){
                              // echo "Records added successfully.";
                             } else{
                              echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
                            }
                           }
                          ?>
                          <label class="bmd-label-floating" name="dn">Session Name</label>
                          <input type="text" class="form-control" name="session_name">
                        </div>
                         <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" name="add_session" class="btn btn-danger btn-sm btn-danger">
                         </div>
                      </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/Footer.php"); ?>
 