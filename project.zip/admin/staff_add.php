<?php include("include/header.php"); 
 $result=mysqli_query($con,"select * from department");
 $s=mysqli_query($con,"select * from session");
 $r=mysqli_query($con,"select * from staff_post");
?>
<div class="content">
<?php
                          if(isset($_POST['staff_details'])){
                            $photo=$_FILES['photo']['name'];
                            $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
                            $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
                            $p_name = mysqli_real_escape_string($con, $_POST['p_name']);
                            $gender= mysqli_real_escape_string($con, $_POST['gender']);
                            $DOB= mysqli_real_escape_string($con, $_POST['DOB']);
                            $mobile_number= mysqli_real_escape_string($con, $_POST['mobile_number']);
                            $email_id = mysqli_real_escape_string($con, $_POST['email_id']);
                            $dep= mysqli_real_escape_string($con, $_POST['dep']);
                            $qualification = mysqli_real_escape_string($con, $_POST['qualification']);
                            $designation= mysqli_real_escape_string($con, $_POST['designation']);
                            $address= mysqli_real_escape_string($con, $_POST['address']);
                            $district= mysqli_real_escape_string($con, $_POST['district']);
                            $block= mysqli_real_escape_string($con, $_POST['block']);
                            $pincode= mysqli_real_escape_string($con, $_POST['pincode']);
                            $password = mysqli_real_escape_string($con, $_POST['password']);
                            $sql = "INSERT INTO `staff_details` (`photo`, `first_name`, `last_name`, `p_name`, `gender`, `DOB`, `mobile_number`, `email_id`, `dep`, `qualification`, `designation`, `address`, `district`, `block`, `pincode`) VALUES ('$photo', '$first_name ', '$last_name', '$p_name', '$gender', '$DOB', '$mobile_number', '$email_id ', '$dep', '$qualification', '$designation', '$address', '$district', '$block', '$pincode')";
                            if(mysqli_query($con, $sql)){
                                 $user_id=mysqli_insert_id($con);
                                move_uploaded_file($_FILES['photo']['tmp_name'],'../staff_images/'.$photo);
                              }
                                $sql1="INSERT INTO `user` (`user_name`,`user_type`,`password`,`detail_id`,`status`) VALUES ('$email_id','staff','$password','$user_id','active')";
                                // print_r($sql1);
                                if(mysqli_query($con,$sql1)){?>
                                   <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Records added successfully";?></span>
                                  </div>
                            <?php  
                             }else{ ?>
                                  <div class="alert alert-Danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Error in adding Staff";?></span>
                                  </div>
                            <?php }
                           }
                          ?>
      
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Add New Staff Detail</h4>
                  <p class="card-category"> Here you can Add New Staff details</p>
                </div>
                <div class="card-body">
                  <form method="post" enctype="multipart/form-data">
                    <div class="row">
                         
                          <div class="col-md-5">
                          <div class="form-group">
                              <label class="bmd-label-floating">Photo</label>
                              <input class="form-control" type="file" name="photo" >
                           </div>
                          </div>
                        </div>
                        <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating"> First Name</label>
                          <input type="text" class="form-control" name="first_name">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"> Last Name</label>
                          <input type="text" class="form-control" name="last_name">
                        </div>
                      </div>
                  </div>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">S/D/W Of</label>
                          <input type="text" class="form-control" name="p_name">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                           <label class="bmd-label-floating">Gender</label>
                          <div class="form-check" style="    display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="gender" value="Male" checked=""> Male
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="gender" value="Female" checked=""> Female
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">DOB</label>
                          <input type="date" class="form-control" name="DOB" >
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile no.</label>
                          <input type="text" class="form-control" name="mobile_number">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Address</label>
                          <input type="email" class="form-control"  name="email_id">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Password</label>
                          <input type="password" class="form-control" name="password">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Department</label>
                          <select class="form-control" name="dep">
                            <?php while ($row=mysqli_fetch_assoc($result)) { ?>
                              <option value="<?=$row['Department_Id']?>"><?=$row['Department_name']?></option>
                            <?php } ?>
                            
                          </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Qualification</label>
                          <input type="text" class="form-control"  name="qualification">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Designation</label>
                          <select class="form-control" name="designation">
                            <?php while ($row=mysqli_fetch_assoc($r)) { ?>
                              <option value="<?=$row['qid']?>"><?=$row['post']?></option>
                            <?php } ?>
                          </select> 
                          <!-- <input type="text" class="form-control" name="designation"> -->
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address</label>
                          <input type="text" class="form-control" name="address">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">District</label>
                          <input type="text" class="form-control" name="district">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Block</label>
                          <input type="text" class="form-control" name="block">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Pin Code</label>
                          <input type="text" class="form-control" name="pincode">
                        </div>
                        <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" class="btn btn-danger btn-sm btn-danger" name="staff_details">
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
