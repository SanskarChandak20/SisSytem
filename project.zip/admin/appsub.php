<?php include("include/header.php"); 
if(isset($_GET['appsub_del_id'])){
  $del=mysqli_query($con,"delete from subject where sub_id=$_GET[appsub_del_id]");
  if($del){
    echo "selected row is deleted";
  }else{
    echo "error in deleting the row";
  }
}
if(isset($_POST['app_edit'])){
  $edit=mysqli_query($con," update subject set sub_name='$_POST[sub_name]' where sub_id=$_POST[appsub_edit_id]");
  if($edit){
    echo "selected row is deleted";
  }else{
    echo "error in deleting the row";
  }
}
 $result=mysqli_query($con,"select * from subject");
echo mysqli_error($con);
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Application Subject Details</h4>
                  <p class="card-category"> Here you get all Application Subject Details</p>
                  <a href="appsub_add.php" class="btn btn-warning btn-sm active">Add</a>
                </div>
               <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="subject">
                      <thead class=" text-danger">
                        <tr>
                          <th>Subject Id</th>
                          <th>Subject  Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['sub_id']?></td>
                          <td><?=$r['sub_name']?></td>
                          <td>
                            <a href="appsub_edit.php?appsub_edit_id=<?=$r['sub_id']?>"class="btn btn-info btn-fab"><i class="material-icons">create</i></a>
                            <a href="appsub.php?appsub_del_id=<?=$r['sub_id']?>"class="btn btn-rose btn-fab"><i class="material-icons">delete</i></a>
                          </td>
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
    $(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#subject').DataTable();
  });
  </script>