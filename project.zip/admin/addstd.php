<?php include("include/header.php"); ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Add New Student Detail</h4>
                  <p class="card-category"> Here you can Add New Student details</p>
                </div>
                <div class="card-body">
                  <form method="post">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <?php
                          if(isset($_POST['student_details'])){
                            $Status = mysqli_real_escape_string($con, $_POST['Status']);
                            $enrollment_no = mysqli_real_escape_string($con, $_POST['enrollment_no']);
                            $first_name = mysqli_real_escape_string($con, $_POST['first_name']);
                            $last_name = mysqli_real_escape_string($con, $_POST['last_name']);
                            $DOB = mysqli_real_escape_string($con, $_POST['DOB']);
                            $p_name = mysqli_real_escape_string($con, $_POST['p_name']);
                            $Gender = mysqli_real_escape_string($con, $_POST['Gender']);
                            $Branch = mysqli_real_escape_string($con, $_POST['Branch']);
                            $Sem = mysqli_real_escape_string($con, $_POST['Sem']);
                            $Caste = mysqli_real_escape_string($con, $_POST['Caste']);
                            $Mobile_no= mysqli_real_escape_string($con, $_POST['Mobile_no']);
                            $Email_id = mysqli_real_escape_string($con, $_POST['Email_id']);
                            $ten= mysqli_real_escape_string($con, $_POST['ten']);
                            $twelve = mysqli_real_escape_string($con, $_POST['twelve']);
                            $cgpa_till_date= mysqli_real_escape_string($con, $_POST['cgpa_till_date']);
                            $Per_address = mysqli_real_escape_string($con, $_POST['Per_address']);
                            $tem_address = mysqli_real_escape_string($con, $_POST['tem_address']);
                            $block= mysqli_real_escape_string($con, $_POST['block']);
                            $district = mysqli_real_escape_string($con, $_POST['district']);
                            $pincode = mysqli_real_escape_string($con, $_POST['pincode']);
                            // $fname = mysqli_real_escape_string($con, $_POST['fname']);
                            // $fname = mysqli_real_escape_string($con, $_POST['fname']);
                            $sql = "INSERT INTO `student_details` (`Status`, `photo`, `S_id`, `enrollment_no`, `first_name`, `last_name`, `DOB`, `p_name`, `Gender`, `Branch`, `Sem`, `Caste`, `Mobile_no`, `Email_id`, `parent's_no`, `ten`, `twelve`, `sem1_sgpa`, `sem2_sgpa`, `sem3_sgpa`, `sem4_sgpa`, `sem5_sgpa`, `sem6_sgpa`, `cgpa _till_date`, `Per_address`, `tem_address`, `post`, `block`, `district`, `pincode`) VALUES ('$Status', '', NULL, '$enrollment_no', '$first_name', '$last_name', '$DOB', '$p_name', '$Gender', '$Branch', '$Sem', '$Caste', '$Mobile_no', '$Email_id', '', '$ten', '$twelve', '', '', '', '', '', '', '$cgpa_till_date', '$Per_address', '$tem_address', '', '$block', '$district', '$pincode')";
                            if(mysqli_query($con, $sql)){
                              // echo "Records added successfully.";
                             } else{
                              echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
                            }
                           }
                          ?>
                            <div class="form-check">
                              <label class="bmd-label-floating" >Status</label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="Status" value="Regular" checked=""> Regular
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="Status" value="Ex" checked=""> EX
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                            </div>
                        </div>
                         <div class="form-group">
                          <label class="bmd-label-floating">Enrollment no.</label>
                          <input type="text" class="form-control"  name="enrollment_no">
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">First Name</label>
                          <input type="text" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Last Name</label>
                          <input type="email" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">S/D/W Of</label>
                          <input type="text" class="form-control">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                           <label class="bmd-label-floating">Gender</label>
                          <div class="form-check" style="    display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="exampleRadios" value="option2" checked=""> Male
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" name="exampleRadios" value="option2" checked=""> Female
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php include("include/footer.php"); ?>
