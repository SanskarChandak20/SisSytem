<?php include("include/header.php"); ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Add New Application Subject</h4>
                  <p class="card-category"> Here you can Add New Application Subject</p>
                </div>
                <div class="card-body">
                  <form method="post">
                    <div class="row">              
                      <div class="col-md-3">
                        <div class="form-group">
                          <?php 
                          if(isset($_POST['add_appsub'])){
                            $sub_name= mysqli_real_escape_string($con, $_POST['sub_name']);
                            $sql = "INSERT INTO subject (sub_name) VALUES ('$sub_name')";
                            if(mysqli_query($con, $sql)){
                              // echo "Records added successfully.";
                             } else{
                              echo "ERROR: Could not able to execute $sql. " . mysqli_error($con);
                            }
                           }
                          ?>
                          <label class="bmd-label-floating" name="dn">Subject Name</label>
                          <input type="text" class="form-control" name="sub_name">
                        </div>
                         <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" name="add_appsub" class="btn btn-danger btn-sm btn-danger">
                         </div>
                      </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/Footer.php"); ?>
 