<?php 
  include("include/header.php");
   if(isset($_GET['Accept_id'])){
    $result1=mysqli_query($con,"update app_leave set status='Accept' where l_id=$_GET[Accept_id]");
  }elseif(isset($_GET['Reject_id'])){
    $result1=mysqli_query($con,"update app_leave set status='Reject' where l_id=$_GET[Reject_id]");
  }
  $result=mysqli_query($con,"select * from app_leave join subject on app_leave.app_subject=subject.sub_id order by l_id");
  $result2=mysqli_query($con,"select * from app_leave join student_details on app_leave.from_id=student_details.S_id order by l_id");
   echo mysqli_error($con);
  ?>
       <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Leave Application</h4>
                  <p class="card-category">Leave Application Details</p>
                  </div>
                  <div>
                  <p class="card-header">Date/Time: <span id="datetime"></span></p>
                  <script>
                    var dt = new Date();
                    document.getElementById("datetime").innerHTML = dt.toLocaleString();
                  </script>
                <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="applications">
                      <thead class="text-danger">
                        <tr>
                          <th>#</th>
                          <th>From</th>
                          <th>Subject</th>
                          <th>Time</th>
                          <th>Status</th>
                          <th>Action</th>
                      </tr></thead>
                      <tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['l_id']?></td>
                          <td><?=$r['from_id']?></td>
                          <td><?=$r['sub_name']?></td>
                          <td><?=$r['time']?></td>
                          <td><?=$r['status']?></td>
                          <td> 
                          <a href="leaveapp_view.php?app_view_id=<?=$r['l_id']?>" class="btn btn-info btn-fab"><i class="material-icons">visibility</i></a>
                          <?php if(!($r['status']=="Accept" ||$r['status']=="Reject")) { ?>             
                          <a href="leave_app.php?Accept_id=<?=$r['l_id']?>" class="btn btn-primary btn-sm btn-round"><i class="fas fa-pen-square"></i>Accept</a>
                          <a href="leave_app.php?Reject_id=<?=$r['l_id']?>" class="btn btn-danger btn-sm btn-round">Reject</a></td>
                      <?php }  }?>  
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
    $(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#applications').DataTable();
  });
  </script>