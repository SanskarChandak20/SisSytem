<?php include("include/header.php"); 
if(isset($_POST['doc_edit_id'])){
  $edit=mysqli_query($con," update document_details set doc_name='$_POST[doc_name]',doc_type='$_POST[doc_type]',doc_desc='$_POST[doc_desc]' where doc_id=$_POST[doc_edit_id]");
  if($edit){
    echo "selected row is deleted";
  }else{
    echo "error in deleting the row";
  }
}
 $result=mysqli_query($con,"select * from doc_details");
echo mysqli_error($con);
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Document Details</h4>
                  <p class="card-category"> Here you get all Document Details</p>
                <a href="doc_add.php" class="btn btn-success btn-fab"><i class="material-icons">open_in_browser</i></a>
                </div>
                <div>
                  <p class="card-header">Date/Time: <span id="datetime"></span></p>
                  <script>
                    var dt = new Date();
                    document.getElementById("datetime").innerHTML = dt.toLocaleString();
                  </script>
                <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="document">
                      <thead class=" text-danger">
                        <tr>
                          <th>#</th>
                          <th>Document Name</th>
                          <th>Document type</th>
                          <th>Description</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['doc_id']?></td>
                          <td><?=$r['doc_name']?></td>
                          <td><?=$r['doc_type']?></td>
                          <td><?=$r['doc_desc']?></td>
                          <td>
                            <a href="doc_edit.php?doc_edit_id=<?=$r['doc_id']?>" src=""  class="btn btn-warning btn-fab"><i class="material-icons">create</i></a>
                            <a href="doc_view.php?doc_view_id=<?=$r['doc_id']?>"  class="btn btn-info btn-fab"><i class="material-icons">visibility</i></a>
                            <!-- <a src="../document/<?=$r['document']?>" href="../document/<?=$r['document']?>"class="btn btn-rose btn-fab"> -->
                              <a src="../document/<?=$r['document']?>" class="btn btn-success btn-fab"><i class="material-icons">save_alt</i></a>
                          </td>
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
    $(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#document').DataTable();
  });
  </script>