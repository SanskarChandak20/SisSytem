<?php include("include/database.php"); 
session_start();
if(!isset($_SESSION['username'])){
  header("location:../login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../sislogo2.png">
  <link rel="icon" type="image/png" href="../sislogo2.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
   Student Information System
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="../assets/css/font-awesome.min.css" />
  <link rel="stylesheet" href="../assets/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
  <link href="../assets/css/css.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="../assets/datatables.css"/>
  <style type="text/css">
     <style type="text/css">
    .material-icons {
  font-family: 'Material Icons';
  font-weight: normal;
  font-style: normal;
  font-size: 24px;
  line-height: 1;
  letter-spacing: normal;
  text-transform: none;
  display: inline-block;
  white-space: nowrap;
  word-wrap: normal;
  direction: ltr;
  -webkit-font-feature-settings: 'liga';
  -webkit-font-smoothing: antialiased;
}

  </style>
  </style>
</head>

<body filter-color="white" style="background-image: url(&#39;../../assets/img/login1.png&#39;); background-size:auto; background-repeat:repeat;">
  <!-- <body> -->
  <div class="wrapper ">
    <div class="sidebar" data-color="red" data-background-color="black" data-image="../front.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo">
        <a href="#" class="simple-text logo-normal">
          <img src="logo.jpg" style="height="51px" width="51px" border-radius="8px">
          <h6>MJP Govertment Polytechnic</h6>
        </a>
      </div>
      <div class="sidebar-wrapper ps-container ps-theme-default ps-active-y" data-ps-id="9d572cf8-a4cd-f1e9-305b-c7955b111972">
       <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href="./Student.php">
              <i class="material-icons">widgets</i>
              <p> Student details</p>
            </a>
          </li>
          <li i class="nav-item active">
            <a class="nav-link" href="./staff_details.php">
              <i class="material-icons">people_outline</i>
              <p>Staff Detail</p>
            </a>
          </li>
          <li class="nav-item  active">
            <a class="nav-link" href="leave_app.php">
              <i class="material-icons">library_books</i>
              <p>Leave Application</p>
            </a>
          </li>
          <li class="nav-item  active">
            <a class="nav-link" href="doc_details.php">
              <i class="material-icons">file_copy</i>
              <p>Documents</p>
            </a>
          </li>
           <li class="nav-item  active">
            <a class="nav-link" href="Accounts.php">
              <i class="material-icons">account_circle</i>
              <p>User Accounts</p>
            </a>
          </li>
          <li class="nav-item ">
                  <a class="nav-link" href="./Department_details.php">
                    <i class="material-icons">school</i>
                    <p>Department Details</p>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="Session_details.php">
                    <i class="material-icons">bookmark</i>
                    <p>Session</p>
                  </a>
                </li>
              <li class="nav-item ">
            <a class="nav-link" href="appsub.php">
              <i class="material-icons">add_to_photos</i>
              <p>app subjects</p>
            </a>
          </li>
          <!-- <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href="./Student.php">
              <i class="material-icons">widgets</i>
              <p> Student details</p>
            </a>
          </li>
         <li i class="nav-item active">
            <a class="nav-link" href="./staff_details.php">
              <i class="material-icons">people_outline</i>
              <p>Staff Detail</p>
            </a>
          </li>
              <li class="nav-item  active">
            <a class="nav-link" href="leave_app.php">
              <i class="material-icons">library_books</i>
              <p>Leave Application</p>
            </a>
          </li>
         <li class="nav-item  active">
            <a class="nav-link" href="doc_details.php">
              <i class="material-icons">assignment</i>
              <p>Documents</p>
            </a>
          </li>
           <li class="nav-item  active">
            <a class="nav-link" href="Accounts.php">
              <i class="material-icons">account_circle</i>
              <p>User Accounts</p>
            </a>
          </li>
          <div class="collapse" id="forms">
              <ul class="nav">
                <li class="nav-item ">
                  <a class="nav-link" href="./Department_details.php">
                    <i class="material-icons">school</i>
                    <p>Department Details</p>
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="Session_details.php">
                    <i class="material-icons">bookmark</i>
                    <p>Session</p>
                  </a>
                </li>
              <li class="nav-item ">
            <a class="nav-link" href="appsub.php">
              <i class="material-icons">add_to_photos</i>
              <p>app subjects</p>
            </a>
          </li>
        </ul>
          </div>

       <li class="nav-item  active">
            <a class="nav-link" href="Placement.php">
              <i class="material-icons">assignment</i>
              <p>Placement details</p>
            </a>
          </li> -->
        </ul>
      </div>
    </div> -->
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="#pablo" style="color: White">Student Information System</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
     
            <ul class="navbar-nav">
              <li class="nav-item dropdown">
                <a class="nav-link" href="#pablo" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">person</i>
                  <p class="d-md-block">
                    <?php echo $_SESSION['username']; ?>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                  <a class="dropdown-item" href="view Profile">Profile</a>
                  <a class="dropdown-item" href="change_password.php">change password</a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="../logout.php">Log out</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
