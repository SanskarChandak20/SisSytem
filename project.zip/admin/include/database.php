<?php 
	$con=mysqli_connect("localhost","root","","sdbms");
	if(!$con){
		die(mysql_connect_error());
	}
?>