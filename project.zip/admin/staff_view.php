<?php include("include/header.php");

if(isset($_GET["stf_view_id"])){
  $result=mysqli_query($con,"select * from staff_details join Department on staff_details.dep= Department.Department_Id where staff_id=$_GET[stf_view_id]");
  $row=mysqli_fetch_assoc($result);
}
 ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">View Staff Detail</h4>
                  <p class="card-category"> Here you can View Staff details</p>
                </div>
                <div class="card-body">
                  <form action=" staff_details.php" method="post" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating">Staff Id</label>
                          <input type="text" class="form-control" disabled="" name="staff_id" value="<?=$row['staff_id']?>">
                        </div>
                      </div> 
                      <div class="col-md-6">               
                       <div class="form-group">
                              <img  width="140" height="40" class="img img-thumbnail " src="../staff_images/<?=$row['photo']?>">
                       </div> 
                     </div>
                   </div>
                   <div class="row">
                      <div class="col-md-5">
                       <div class="form-group">
                          <label class="bmd-label-floating"> First Name</label>
                          <input type="text" class="form-control" disabled="" name="first_name" value="<?=$row['first_name']?>">
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-group">
                          <label class="bmd-label-floating"> Last Name</label>
                          <input type="text" class="form-control" disabled="" name="last_name" value="<?=$row['last_name']?>">
                        </div>
                      </div>
                  </div>
                    <div class="row">
                      <div class="col-md-8">
                        <div class="form-group">
                          <label class="bmd-label-floating">S/D/W Of</label>
                          <input type="text" class="form-control" disabled="" name="p_name" value="<?=$row['p_name']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                           <label class="bmd-label-floating">Gender</label>
                          <div class="form-check" style="    display: inline-block;margin-left: 20px;">
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" disabled="" name="gender" value="Male" <?php if($row['gender']=='Male'){ echo "checked";} ?>> Male
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                              <label class="form-check-label">
                                <input class="form-check-input" type="radio" disabled="" name="gender" value="Female" <?php if($row['gender']=='Female'){ echo "checked";} ?>> Female
                                <span class="circle">
                                  <span class="check"></span>
                                </span>
                              </label>
                          </div>                      
                        </div>
                     </div >
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">DOB</label>
                          <input type="date" class="form-control" disabled="" name="DOB" value="<?=$row['DOB']?>" >
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Mobile no.</label>
                          <input type="text" class="form-control" disabled="" name="mobile_number"  value="<?=$row['mobile_number']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Email Address</label>
                          <input type="email" class="form-control" disabled="" name="email_id"  value="<?=$row['email_id']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Department</label>
                             <input type="email" class="form-control" disabled="" name="email_id"  value="<?=$row['Department_name']?>">
                        <!--  <select class="form-control" name="dep">
                            <?php while ($row=mysqli_fetch_assoc($ed)) { ?>
                              <option value="<?=$row['Department_Id']?>"><?=$row['Department_name']?></option>
                            <?php } ?>
                            
                          </select>    -->
                          </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Qualification</label>
                          <input type="text" class="form-control" disabled="" name="qualification"  value="<?=$row['qualification']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Designation</label>
                          <input type="text" class="form-control" disabled="" name="designation"  value="<?=$row['designation']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Address</label>
                          <input type="text" class="form-control" disabled="" name="address"  value="<?=$row['address']?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">District</label>
                          <input type="text" class="form-control" disabled="" name="district"  value="<?=$row['district']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Block</label>
                          <input type="text" class="form-control" disabled="" name="block"  value="<?=$row['block']?>">
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Pin Code</label>
                          <input type="text" class="form-control" disabled="" name="pincode" value="<?=$row['pincode']?>">
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
