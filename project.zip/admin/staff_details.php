<?php include("include/header.php"); ?>
<div class="content">
<?php  
if(isset($_GET['stf_del_id'])){
  $del2=mysqli_query($con,"delete from user where detail_id=$_GET[stf_del_id] and user_type='staff'");  
 if(mysqli_query($con,"delete from staff_details where staff_id=$_GET[stf_del_id]")){?>
        <div class="alert alert-success"> 
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="material-icons">close</i>
          </button>
          <span><?php echo "Records deleted successfully";?></span>
        </div>
<?php }else{ ?>
      <div class="alert alert-Danger">
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="material-icons">close</i>
          </button>
          <span><?php echo "Error in deleting";?></span>
      </div>
<?php }
} ?>
<?php 
if(isset($_POST['stf_edit'])){
        $photo=$_FILES['photo']['name'];
        //echo $photo;
        $edit='';
        if($photo==''){
            $edit=mysqli_query($con,"update staff_details set first_name='$_POST[first_name]',last_name='$_POST[last_name]',p_name='$_POST[p_name]',DOB='$_POST[DOB]',mobile_number='$_POST[mobile_number]',email_id='$_POST[email_id]',dep='$_POST[dep]',qualification='$_POST[qualification]',designation='$_POST[designation]',address='$_POST[address]',district='$_POST[district]',block='$_POST[block]',pincode='$_POST[pincode]' ,gender='$_POST[gender]' where staff_id=$_POST[staff_id]");
        }else{
            $edit=mysqli_query($con,"update staff_details set photo='$photo',first_name='$_POST[first_name]',last_name='$_POST[last_name]',p_name='$_POST[p_name]',DOB='$_POST[DOB]',mobile_number='$_POST[mobile_number]',email_id='$_POST[email_id]',dep='$_POST[dep]',qualification='$_POST[qualification]',designation='$_POST[designation]',address='$_POST[address]',district='$_POST[district]',block='$_POST[block]',pincode='$_POST[pincode]' ,gender='$_POST[gender]' where staff_id=$_POST[staff_id]");
        }
                  // var_dump($edit);
        echo mysqli_error($con);
        if ($edit){ 
            if($photo!=''){
            move_uploaded_file($_FILES['photo']['tmp_name'], '../staff_images'.$photo);
          }
          ?>
          <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i class="material-icons">close</i>
            </button>
            <span><?php echo "Records added successfully"; ?></span>
          </div>
      <?php }else{ ?>
          <div class="alert alert-success">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i class="material-icons">close</i>
            </button>
            <span><?php echo "Error"; ?></span>
          </div>
      <?php } 
}
$result=mysqli_query($con,"select * from staff_details join department on staff_details.dep= department.Department_Id ");
echo mysqli_error($con);
 ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Staff Detail</h4>
                  <p class="card-category"> Here you can get Staff details</p>
                <a href="staff_add.php" class="btn btn-success btn-fab"><i class="material-icons">add_circle_outline</i></a>
                </div>
                <div>
                  <p class="card-header">Date/Time: <span id="datetime"></span></p>
                  <script>
                    var dt = new Date();
                    document.getElementById("datetime").innerHTML = dt.toLocaleString();
                  </script>
                <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="staff">
                      <thead class="text-danger">
                        <tr>
                         <th>Staff ID</th>
                         <th>First Name</th>
                         <th>Last Name</th>
                         <th>E-mail Id</th>
                         <th>Department</th>
                         <th>Qualification</th>
                         <th>Designation</th>
                         <th>Action</th>
                        </tr></thead>
                      <tbody>
                       <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['staff_id']?></td>
                          <td><?=$r['first_name']?></td>
                          <td><?=$r['last_name']?></td>
                          <td><?=$r['email_id']?></td>
                          <td><?=$r['Department_name']?></td>
                          <td><?=$r['qualification']?></td>
                          <td><?=$r['designation']?></td>
                          <td>
                            <a href="staff_edit.php?stf_edit_id=<?=$r['staff_id']?>" class="btn btn-warning btn-fab"><i class="material-icons">create</i></a>
                            <a href="staff_view.php?stf_view_id=<?=$r['staff_id']?>" class="btn btn-info btn-fab"><i class="material-icons">visibility</i></a>
                            <a href="staff_details.php?stf_del_id=<?=$r['staff_id']?>" class="btn btn-rose btn-fab"><i class="material-icons">delete</i></a>
                          </td>
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
    $(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#staff').DataTable();
  });
  </script>