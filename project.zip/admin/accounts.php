  <?php 
  include("include/header.php");

  if(isset($_GET['active_id'])){
    $result1=mysqli_query($con,"update user set status='active' where detail_id=$_GET[active_id]");
  }elseif(isset($_GET['deactive_id'])){
    $result1=mysqli_query($con,"update user set status='deactive' where detail_id=$_GET[deactive_id]");
    // $result2=mysqli_query($con,"delete from staff_details where staff_id=$_GET[deactive_id]");
  }
   $result=mysqli_query($con,"select * from user");
  ?>
       <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">All Account Details</h4>
                  <p class="card-category"> Here you can get all User Accounts details</p>
                </div>
                <div class="card-body">
                  <div class=" material-datatables table-responsive">
                    <table class="table display" id="user">
                      <thead class=" text-danger">
                        <tr>
                          <th>User name</th>
                        <th>User Type</th>
                        <th>Change Status</th>
                      </tr></thead>
                      <tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['user_name']?></td>
                          <td><?=$r['user_type']?></td>
                          <td>
                          <?php if($r['status']=="deactive") { ?>             
                          <a href="accounts.php?active_id=<?=$r['detail_id']?>" class="btn btn-primary btn-sm btn-round">Active</a>
                          <?php }?>
                          <?php if($r['status']=="active") { ?>
                          <a href="accounts.php?deactive_id=<?=$r['detail_id']?>" class="btn btn-danger btn-sm btn-round">Deactive</a>
                          <?php }?>
                        </td>
                        </tr>
                      <?php  }?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript">
  
    $(document).ready(function() {
      $('#datatables').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }
      });

      var table = $('#user').DataTable();
  });
  </script>
