<?php include("include/header.php"); 
if(isset($_GET["dep_edit_id"])){
  $result=mysqli_query($con,"select * from Department where Department_Id=$_GET[dep_edit_id]");
  $row=mysqli_fetch_assoc($result);
}
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Edit Department Detail</h4>
                  <p class="card-category"> Here you can Edit  Department detail</p>
                </div>
                <div class="card-body">
                  <form action="Department_details.php" method="post">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Department Id</label>
                          <input type="text" class="form-control" readonly="" name="Department_Id" value="<?=$row['Department_Id']?>">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Department Name</label>
                          <input type="text" class="form-control" name="Department_name" value="<?=$row['Department_name']?>">
                        </div>
                        <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" name="dep_edit" class="btn btn-danger btn-sm btn-danger" >
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>