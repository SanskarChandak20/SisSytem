<?php include("include/header.php"); 
if(isset($_GET["dep_view_id"])){
  $result=mysqli_query($con,"select * from Department where Department_Id=$_GET[dep_view_id]");
  $row=mysqli_fetch_assoc($result);
}
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">View Department Detail</h4>
                  <p class="card-category"> Here you can View Department details</p>
                </div>
                <div class="card-body">
                  <form method="post" action="department_details.php">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Department Id</label>
                          <input type="text" class="form-control" disabled="" value="<?=$row['Department_Id']?>">
                        </div>
                      </div>
                          <div class="col-md-3">
                           <div class="form-group">
                             <label class="bmd-label-floating">Department Name</label>
                             <input type="text" class="form-control" disabled="" value="<?=$row['Department_name']?>">
                            </div>
                          </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>