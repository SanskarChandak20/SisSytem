<?php include("include/header.php"); ?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Add New Document</h4>
                  <p class="card-category"> Here you can Add New Document</p>
                </div>
                <div class="card-body">
                  <form method="post" enctype="multipart/form-data">
                    <div class="row">              
                      <div class="col-md-3">
                        <div class="form-group">
                          <?php 
                          if(isset($_POST['doc_add'])){
                            $doc_name= mysqli_real_escape_string($con, $_POST['doc_name']);
                            $doc_type= mysqli_real_escape_string($con, $_POST['doc_type']);
                            $doc_desc= mysqli_real_escape_string($con, $_POST['doc_desc']);
                            $document=$_FILES['document']['name'];
                            $sql = "INSERT INTO doc_details (doc_name,doc_type,doc_desc,document) VALUES ('$doc_name','$doc_type','$doc_desc','$document')";
                            if(mysqli_query($con, $sql)){
                                move_uploaded_file($_FILES['document']['tmp_name'],'../document/'.$document);
                             echo "Records added successfully.";
                             } else{
                             echo mysqli_error($con);
                            }
                           }
                          ?>
                          <label class="bmd-label-floating">Document Name</label>
                          <input type="text" class="form-control" name="doc_name">
                        </div>
                        </div>
                        <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Document Type</label>
                          <input type="text" class="form-control" name="doc_type">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="form-group">
                          <label class="bmd-label-floating">Document description</label>
                          <input type="text" class="form-control" name="doc_desc">
                        </div>
                      </div>
                      <div class="col-md-3">
                              <label class="bmd-label-floating">Document Upload</label>
            
                              <input class="form-control" type="file" name="document" >
                           </div>
                         <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" name="doc_add" class="btn btn-danger btn-sm btn-danger">
                         </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/Footer.php"); ?>
 