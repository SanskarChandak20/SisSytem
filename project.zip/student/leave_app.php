<?php 
  include("include/header.php");
  
 
  // if(isset($_GET['Accept_id'])){
  //   $result1=mysqli_query($con,"update app_leave set status='Accept' where l_id=$_GET[Accept_id]");
  // }elseif(isset($_GET['Reject_id'])){
  //   $result1=mysqli_query($con,"update app_leave set status='Reject' where l_id=$_GET[Reject_id]");
  // }
  // echo "select * from app_leave join subject on app_leave.app_subject=subject.sub_id where from_id=$_SESSION[stdid]";
  $result=mysqli_query($con,"select * from app_leave join subject on app_leave.app_subject=subject.sub_id where from_id=$_SESSION[stdid]");
   echo mysqli_error($con);
  ?>
       <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Leave Application</h4>
                  <p class="card-category">Leave Application Details</p>
                   <a href="add_leave.php" class="btn btn-warning btn-sm active">Add</a>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead class=" text-danger">
                        <tr>
                          <th>#</th>
                          <th>From</th>
                          <th>Subject</th>
                          <th>Time</th>
                          <th>Status</th>
                          <th>Action</th>
                      </tr></thead>
                      <tbody>
                      </tbody>
                      <?php while ($r=mysqli_fetch_assoc($result)) {?>
                        <tr>
                          <td><?=$r['l_id']?></td>
                          <td><?=$r['from_id']?></td>
                          <td><?=$r['sub_name']?></td>
                          <td><?=$r['time']?></td>
                          <td><?=$r['status']?></td>
                          <td> 
                          <a href="leaveapp_view.php?app_view_id=<?=$r['l_id']?>" class="btn btn-success btn-sm btn-round">View</a> 
                          </td>
                      <?php }  ?>  
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("include/footer.php"); ?>