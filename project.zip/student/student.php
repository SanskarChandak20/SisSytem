<?php 
include("include/header.php");
if (isset($_GET['std_del_id'])){
 $del=mysqli_query($con,"delete from student_details where S_id=$_GET[std_del_id]");  

 if($del){?>

 <div class="content">
 <div class="alert alert-success">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<i class="material-icons">close</i>
</button>
<span><?php echo "Records deleted successfully";?></span>
</div>
<?php  
}else{ ?>
 <div class="alert alert-Danger">
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<i class="material-icons">close</i>
</button>
<span><?php echo "Error in deleting";?></span>
</div>
</div>?>
 <?php }
}
if(isset($_POST['student_details'])){
  // print_r($_FILES);
  $photo=$_FILES['photo']['name'];
  if ($photo=='') {
   $edit=mysqli_query($con,"update student_details set Status='$_POST[Status]',enrollment_no='$_POST[enrollment_no]',first_name='$_POST[first_name]',last_name='$_POST[last_name]',p_name='$_POST[p_name]',p_no='$_POST[p_no]',gender='$_POST[gender]',DOB='$_POST[DOB]',Mobile_no='$_POST[Mobile_no]',Email_id='$_POST[Email_id]',Branch='$_POST[Branch]',Sem='$_POST[Sem]',Caste='$_POST[Caste]',Per_address='$_POST[Per_address]',tem_address='$_POST[tem_address]',district='$_POST[district]',block='$_POST[block]',pincode='$_POST[pincode]',ten='$_POST[ten]',twelve='$_POST[twelve]',cgpa='$_POST[cgpa]',sem1_sgpa='$_POST[sem1_sgpa]',sem2_sgpa='$_POST[sem2_sgpa]',sem3_sgpa='$_POST[sem3_sgpa]',sem4_sgpa='$_POST[sem4_sgpa]',sem5_sgpa='$_POST[sem5_sgpa]',sem6_sgpa='$_POST[sem6_sgpa]',passout='$_POST[passout]' where S_id=$_POST[S_id]");
    
  }else{
    $edit=mysqli_query($con,"update student_details set Status='$_POST[Status]',photo='$photo',enrollment_no='$_POST[enrollment_no]',first_name='$_POST[first_name]',last_name='$_POST[last_name]',p_name='$_POST[p_name]',p_no='$_POST[p_no]',gender='$_POST[gender]',DOB='$_POST[DOB]',Mobile_no='$_POST[Mobile_no]',Email_id='$_POST[Email_id]',Branch='$_POST[Branch]',Sem='$_POST[Sem]',Caste='$_POST[Caste]',Per_address='$_POST[Per_address]',tem_address='$_POST[tem_address]',district='$_POST[district]',block='$_POST[block]',pincode='$_POST[pincode]',ten='$_POST[ten]',twelve='$_POST[twelve]',cgpa='$_POST[cgpa]',sem1_sgpa='$_POST[sem1_sgpa]',sem2_sgpa='$_POST[sem2_sgpa]',sem3_sgpa='$_POST[sem3_sgpa]',sem4_sgpa='$_POST[sem4_sgpa]',sem5_sgpa='$_POST[sem5_sgpa]',sem6_sgpa='$_POST[sem6_sgpa]',passout='$_POST[passout]' where S_id=$_POST[S_id]");
      if(mysqli_query($con, $edit)){
          move_uploaded_file($_FILES['photo']['tmp_name'],'../student_images/'.$photo);
           //echo "Records added successfully.";
            }else{
           //echo mysqli_error($con);
              }}
if($edit){?>
   <!-- <? move_uploaded_file($_FILES['photo']['tmp_name'],'../staff_images/'.$photo);?> -->
                                   <div class="content">
                                   <div class="alert alert-success">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Records added successfully";?></span>
                                  </div>
                            <?php  
                             }else{ ?>
                                  <div class="alert alert-Danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                    </button>
                                    <span><?php echo "Error in adding Staff";?></span>
                                  </div>
                                </div>
                            <?php }
                           }
 $result=mysqli_query($con,"select * from student_details join department on student_details.Branch= department.Department_Id");
echo mysqli_error($con);
  ?>
<?php include("include/footer.php"); ?>