<?php include ("include/header.php"); 
  $result=mysqli_query($con,"select * from staff_details where dep=$_SESSION[bid] and status='active'");
  $user_type="staff";//student
  $s=mysqli_query($con,"select * from subject");
?>
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-danger">
                  <h4 class="card-title ">Apply for leave Application</h4>
                  <p class="card-category"> Here you can Apply for leave Application</p>
                </div>
                <div class="card-body">
                  <form method="post" action="add_leave.php">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <?php
                          
                          if(isset($_POST['leave_app'])){
                            $ad1=mysqli_query($con, "INSERT INTO `app_leave` (`to_id`, `app_subject`, `message`, `from_id`) VALUES ('$_POST[to_id]','$_POST[sub]','$_POST[message]','$_SESSION[stdid]')");
                            if($ad1){?>
                                      <div class="content">
                                       <div class="alert alert-success">
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                      </button>
                                      <span><?php echo "Application Send Successfully";?></span>
                                      </div>
                                      <?php  
                                      }else{ ?>
                                       <div class="alert alert-Danger">
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                      <i class="material-icons">close</i>
                                      </button>
                                      <span><?php echo "Error";?></span>
                                      </div>
                                      </div>
                                   <?php }
                           }
                          ?>
                     <div class="row">
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">To</label>
                           <select class="form-control" name="to_id">
                           <?php while ($row1=mysqli_fetch_assoc($result)) {?>
                            <option value="<?=$row1['staff_id']?>"><?=$row1['first_name']?>&nbsp;<?=$row1['last_name']?></option>
                          <?php } ?>
                         </select>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="form-group">
                          <label class="bmd-label-floating">Subject</label>
                         <select class="form-control" name="sub">
                           <?php while ($row=mysqli_fetch_assoc($s)) {?>
                            <option value="<?=$row['sub_id']?>"><?=$row['sub_name']?></option>
                          <?php } ?>
                         </select>
                        </div>
                      </div>
                        <input type="hidden" class="form-control" name="form_id" value="1" >  
                      <div class="col-md-12">
                        <div class="form-group">
                          <label class="bmd-label-floating">Message</label>
                          <textarea rows="10" class="form-control" name="message"></textarea>
                        </div>
                      </div>
                       <div class="form-group"  style="margin-left:15px" width:"88px">
                          <input type="submit" value="submit" class="btn btn-danger btn-sm btn-danger" name="leave_app">
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include ("include/footer.php"); ?>